<?php

class User_model
{
    private $nama = 'Tubagus Naufal';

    public function getUser()
    {
        return $this->nama;
    }
}
